<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

  <!-- jQuery, Popper.js, Bootstrap JS -->
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- Animate CSS -->
  <link href="css/animate.css" rel="stylesheet">
  <!-- Lettering js -->
  <script src="js/jquery.lettering.js"></script>
  <!-- Textillate js -->
  <script src="js/jquery.textillate.js"></script>
  
  <?php include("js/script.php"); ?>